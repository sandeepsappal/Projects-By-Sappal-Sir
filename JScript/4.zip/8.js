function showFoodDetails()
{ var price
  if(food.value=="Chola Bhatura")
  { price=120}
  else if(food.value=="Pav Bhaji")
    { price=100}
  else if(food.value=="Paneer Tikka")
    { price=250}
    
  result.innerHTML="Selected Food:"+food.value+"<br>Price:"+p
  
}





